"""
Module for generating and capturing images of the FTDC result window.
Supports:
1. Native window snapshot capture via Windows PrintWindow API (exact pixel capture of Tkinter window).
2. Pure Python / Pillow programmatic rendering fallback (guarantees image generation in headless / background modes).
"""
import logging
import os
import re
import textwrap
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image, ImageDraw, ImageFont

from apps.ftdc_checker.excel_output import build_summary_and_details, _fmt
from apps.ftdc_checker.guid_analysis import compute_remarks


def get_default_result_image_name(result: Dict[str, Any], timestamp: Optional[str] = None) -> str:
    """Return standard result image filename, e.g. {LOT}_FTDC_Result_{YYYYMMDDHHMMSS}.png."""
    lot_text = str(result.get("mir_lot_id") or result.get("lot_id") or "STDF_GUID_Result").strip().upper() or "STDF_GUID_Result"
    safe_lot = re.sub(r"[^A-Za-z0-9_.-]+", "_", lot_text).strip("._") or "STDF_GUID_Result"
    ts = timestamp or datetime.now().strftime("%Y%m%d%H%M%S")
    return f"{safe_lot}_FTDC_Result_{ts}.png"


def capture_window_to_image(window: Any, out_path: str) -> bool:
    """Capture a Tkinter window client area using Windows PrintWindow API.

    Returns True if successfully captured and saved, False otherwise.
    """
    if window is None:
        return False
    try:
        if not getattr(window, "winfo_exists", lambda: False)():
            return False
        window.update_idletasks()
        hwnd = int(window.winfo_id())
        if not hwnd:
            return False

        import ctypes
        from ctypes import windll, wintypes, byref

        rect = wintypes.RECT()
        if not windll.user32.GetClientRect(hwnd, byref(rect)):
            return False
        w = rect.right - rect.left
        h = rect.bottom - rect.top
        if w <= 10 or h <= 10:
            return False

        hdc_screen = windll.user32.GetDC(hwnd)
        if not hdc_screen:
            return False
        hdc_mem = windll.gdi32.CreateCompatibleDC(hdc_screen)
        hbm = windll.gdi32.CreateCompatibleBitmap(hdc_screen, w, h)
        windll.gdi32.SelectObject(hdc_mem, hbm)

        # Flag 2: PW_RENDERFULLCONTENT (captures layered/modern content)
        res = windll.user32.PrintWindow(hwnd, hdc_mem, 2)
        if not res:
            res = windll.user32.PrintWindow(hwnd, hdc_mem, 0)

        class BITMAPINFOHEADER(ctypes.Structure):
            _fields_ = [
                ("biSize", wintypes.DWORD),
                ("biWidth", wintypes.LONG),
                ("biHeight", wintypes.LONG),
                ("biPlanes", wintypes.WORD),
                ("biBitCount", wintypes.WORD),
                ("biCompression", wintypes.DWORD),
                ("biSizeImage", wintypes.DWORD),
                ("biXPelsPerMeter", wintypes.LONG),
                ("biYPelsPerMeter", wintypes.LONG),
                ("biClrUsed", wintypes.DWORD),
                ("biClrImportant", wintypes.DWORD),
            ]

        class BITMAPINFO(ctypes.Structure):
            _fields_ = [("bmiHeader", BITMAPINFOHEADER), ("bmiColors", wintypes.DWORD * 3)]

        bmi = BITMAPINFO()
        bmi.bmiHeader.biSize = ctypes.sizeof(BITMAPINFOHEADER)
        bmi.bmiHeader.biWidth = w
        bmi.bmiHeader.biHeight = -h  # top-down DIB
        bmi.bmiHeader.biPlanes = 1
        bmi.bmiHeader.biBitCount = 32
        bmi.bmiHeader.biCompression = 0

        buf = ctypes.create_string_buffer(w * h * 4)
        windll.gdi32.GetDIBits(hdc_mem, hbm, 0, h, buf, byref(bmi), 0)

        windll.gdi32.DeleteObject(hbm)
        windll.gdi32.DeleteDC(hdc_mem)
        windll.user32.ReleaseDC(hwnd, hdc_screen)

        img = Image.frombuffer("RGBA", (w, h), buf, "raw", "BGRA", 0, 1).convert("RGB")
        extrema = img.getextrema()
        if all(mn == mx for mn, mx in extrema):
            return False

        os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
        img.save(out_path, format="PNG")
        return os.path.isfile(out_path) and os.path.getsize(out_path) > 0
    except Exception as exc:
        logging.warning("PrintWindow capture failed: %s", exc)
        return False


def _get_font(name: str, size: int) -> ImageFont.ImageFont:
    """Safely load a TrueType font or fallback to Pillow default font."""
    try:
        return ImageFont.truetype(name, size)
    except Exception:
        return ImageFont.load_default()


def render_result_image(result: Dict[str, Any], out_path: str) -> bool:
    """Generate a clean programmatic rendering of the FTDC result window.

    Matches the exact layout and color palette of the Tkinter Result Popup:
    - Title: Automatic FTDC Checker & Lot ID
    - Truncated files warning card (if any)
    - Side-by-side comparative matrices (First Pass & Total Good)
    - Remarks card with green/red status highlighting
    """
    summary_sections, _, fp_status, total_status, _, _ = build_summary_and_details(result)
    remarks_text = str(result.get("remarks") or compute_remarks(result)).strip()

    f_title = _get_font("segoeuib.ttf", 15)
    f_head = _get_font("segoeuib.ttf", 12)
    f_body = _get_font("segoeui.ttf", 11)
    f_bold = _get_font("segoeuib.ttf", 11)
    f_sm = _get_font("segoeui.ttf", 10)

    # Measure exact label and value widths so the right-hand value column auto-adjusts
    _probe_draw = ImageDraw.Draw(Image.new("RGB", (1, 1)))
    max_lbl_px = max(
        (_probe_draw.textbbox((0, 0), f"{m}:", font=f_body)[2] for _, rows in summary_sections for m, _ in rows),
        default=260,
    )
    max_val_px = max(
        (_probe_draw.textbbox((0, 0), _fmt(v), font=f_bold)[2] for _, rows in summary_sections for _, v in rows),
        default=60,
    )
    req_col_w = max(431, max_lbl_px + max_val_px + 44)
    img_w = max(900, req_col_w * 2 + 38)
    max_rows = max(len(sec[1]) for sec in summary_sections) if summary_sections else 8
    truncated_list = result.get("truncated_files") or []

    warn_h = (28 + len(truncated_list) * 18) if truncated_list else 0
    header_h = 42
    table_row_h = 24
    table_content_h = max_rows * table_row_h
    table_box_h = 28 + table_content_h + 4

    wrapped_remarks = textwrap.wrap(remarks_text, width=95) or [""]
    remarks_h = 24 + len(wrapped_remarks) * 18
    footer_h = 24

    img_h = header_h + (warn_h + 8 if warn_h else 0) + table_box_h + remarks_h + footer_h + 24

    img = Image.new("RGB", (img_w, img_h), "#F0F0F2")
    draw = ImageDraw.Draw(img)

    y = 10
    lot_id = str(result.get("mir_lot_id") or result.get("lot_id") or "N/A")
    draw.text((15, y), f"Automatic FTDC Checker — {lot_id}", fill="#111111", font=f_title)
    y += 32

    # Truncated warnings card
    if truncated_list:
        draw.rounded_rectangle([15, y, img_w - 15, y + warn_h], radius=4, fill="#FFF3CD", outline="#FFEEBA")
        draw.text((25, y + 5), "⚠️ WARNING: Truncated or corrupted STDF file(s) detected during analysis:", fill="#856404", font=f_bold)
        wy = y + 24
        for tf in truncated_list:
            reasons = []
            if not tf.get("ended_at_eof"):
                reasons.append("Premature EOF")
            if not tf.get("last_record_was_mrr"):
                reasons.append("Missing MRR record")
            if tf.get("pcr_part_cnt") is not None and tf.get("prr_count") != tf.get("pcr_part_cnt"):
                reasons.append(f"PRR ({tf.get('prr_count')}) != PCR ({tf.get('pcr_part_cnt')})")
            r_txt = ", ".join(reasons) if reasons else "Truncated file"
            draw.text((35, wy), f"• [{tf.get('panel')}] {tf.get('filename')}: {r_txt}", fill="#856404", font=f_sm)
            wy += 16
        y += warn_h + 8

    # Side-by-side matrices
    col_w = (img_w - 38) // 2
    for c_idx, (sec_title, rows) in enumerate(summary_sections):
        x0 = 15 if c_idx == 0 else 23 + col_w
        x1 = x0 + col_w
        ty0 = y
        ty1 = y + table_box_h

        # Outer border
        draw.rounded_rectangle([x0, ty0, x1, ty1], radius=4, fill="#FFFFFF", outline="#B7B7B7")
        # Header banner
        draw.rectangle([x0 + 1, ty0 + 1, x1 - 1, ty0 + 26], fill="#F0F0F0")
        draw.line([(x0, ty0 + 26), (x1, ty0 + 26)], fill="#B7B7B7", width=1)
        draw.text((x0 + 8, ty0 + 5), sec_title, fill="#000000", font=f_head)

        # Auto-adjusted vertical separator for the right-hand value column
        panel_max_val_px = max(
            (draw.textbbox((0, 0), _fmt(v), font=f_bold)[2] for _, v in rows),
            default=40,
        )
        val_sep_x = x1 - (panel_max_val_px + 20)
        draw.line([(val_sep_x, ty0 + 26), (val_sep_x, ty1)], fill="#E0E0E0", width=1)

        ry = ty0 + 27
        for r_idx, (metric, val) in enumerate(rows):
            val_str = _fmt(val)
            val_fg = "#000000"

            if metric == "Result":
                val_fg = "#008000" if str(val_str).upper() == "PASS" else "#C00000"
            elif "Difference between Good" in metric:
                if val is None or str(val).strip().upper() in ("N/A", ""):
                    val_str = "N/A"
                    val_fg = "#6C757D"
                else:
                    try:
                        num_val = float(str(val).replace(",", ""))
                        val_str = f"{int(num_val):,}" if num_val.is_integer() else f"{num_val:,.2f}"
                        val_fg = "#008000" if num_val >= 0 else "#C00000"
                    except Exception:
                        val_fg = "#6C757D"
            elif metric.startswith("Duplicate MACID"):
                nums = [int(n) for n in re.findall(r"\d+", str(val_str).replace(",", ""))]
                has_dup = (
                    any(n > 0 for n in nums)
                    or (result.get("duplicate_bt_macid", 0) or 0) > 0
                    or (result.get("duplicate_zb_macid", 0) or 0) > 0
                    or (result.get("duplicate_macid", 0) or 0) > 0
                )
                val_fg = "#C00000" if has_dup else "#008000"
            elif metric.startswith("Unique Valid Good"):
                nums = [int(n) for n in re.findall(r"\d+", str(val_str).replace(",", ""))]
                disc_key = "fp_good_unique_discrepancy" if c_idx == 0 else "total_good_unique_discrepancy"
                disc_val = int(result.get(disc_key, 0) or 0)
                has_disc = disc_val > 0 or len(set(nums)) > 1
                val_fg = "#C00000" if has_disc else "#008000"
            elif metric in ("Duplicate BT MACID", "Duplicate ZB MACID") or metric.startswith("Discrepancy in Good Unique Count"):
                try:
                    num_val = int(float(str(val or 0).replace(",", "")))
                    val_fg = "#C00000" if num_val > 0 else "#008000"
                except Exception:
                    val_fg = "#008000"

            # Draw row separator line
            if r_idx > 0:
                draw.line([(x0 + 1, ry), (x1 - 1, ry)], fill="#E0E0E0", width=1)

            # Metric label on the left
            draw.text((x0 + 8, ry + 4), f"{metric}:", fill="#222222", font=f_body)

            # Metric value right-aligned
            bbox = draw.textbbox((0, 0), val_str, font=f_bold)
            val_w = bbox[2] - bbox[0]
            draw.text((x1 - 12 - val_w, ry + 4), val_str, fill=val_fg, font=f_bold)
            ry += table_row_h

    y += table_box_h + 8

    # Remarks Card
    rem_is_pass = (remarks_text == "No abnormalities or discrepancies were observed.")
    rem_fg = "#008000" if rem_is_pass else "#C00000"
    draw.rounded_rectangle([15, y, img_w - 15, y + remarks_h], radius=4, fill="#FFFFFF", outline="#B7B7B7")
    draw.text((22, y + 6), "Remarks:", fill="#111111", font=f_bold)

    rem_x = 90
    rem_y = y + 6
    for line in wrapped_remarks:
        draw.text((rem_x, rem_y), line, fill=rem_fg, font=f_bold)
        rem_y += 18

    # Footer
    y += remarks_h + 6
    ts_now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    draw.text((18, y), f"Generated: {ts_now}", fill="#888888", font=f_sm)

    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
    img.save(out_path, format="PNG")
    return os.path.isfile(out_path) and os.path.getsize(out_path) > 0


def save_result_window_image(result: Dict[str, Any], out_path: str, window: Any = None) -> str:
    """Save result window image, attempting native window capture first, then falling back to programmatic render."""
    if window is not None:
        if capture_window_to_image(window, out_path):
            return out_path
    render_result_image(result, out_path)
    return out_path
